package de.baldurskreativa.aster;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

public class OtterOverlayService extends Service {
    private WindowManager wm; private ImageView pet; private WindowManager.LayoutParams params;
    private final int[] poses = {R.drawable.otter_idle,R.drawable.otter_happy,R.drawable.otter_curious,R.drawable.otter_ball,R.drawable.otter_play_ball,R.drawable.otter_love,R.drawable.otter_heart,R.drawable.otter_run,R.drawable.otter_roll,R.drawable.otter_pleased,R.drawable.otter_yawn,R.drawable.otter_fish,R.drawable.otter_window_peek};
    private int pose=0, size=190; private float downX,downY,startX,startY; private long downAt; private boolean dragged;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onCreate(){super.onCreate(); showPet();}
    private void showPet(){
        if(pet!=null)return; wm=(WindowManager)getSystemService(WINDOW_SERVICE); pet=new ImageView(this); pet.setImageResource(poses[pose]); pet.setScaleType(ImageView.ScaleType.FIT_CENTER); pet.setBackgroundColor(0x00000000); pet.setPadding(0,0,0,0);
        params=new WindowManager.LayoutParams(dp(size),dp(size),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT); params.gravity=Gravity.TOP|Gravity.START; params.x=dp(30);params.y=dp(180);
        pet.setOnTouchListener((v,e)->{switch(e.getAction()){
            case MotionEvent.ACTION_DOWN: downX=e.getRawX();downY=e.getRawY();startX=params.x;startY=params.y;downAt=System.currentTimeMillis();dragged=false;return true;
            case MotionEvent.ACTION_MOVE: float dx=e.getRawX()-downX,dy=e.getRawY()-downY;if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))dragged=true;params.x=(int)(startX+dx);params.y=(int)(startY+dy);try{wm.updateViewLayout(pet,params);}catch(Exception ignored){}return true;
            case MotionEvent.ACTION_UP: if(!dragged){long held=System.currentTimeMillis()-downAt;if(held>550){size=size==190?240:size==240?145:190;params.width=dp(size);params.height=dp(size);wm.updateViewLayout(pet,params);Toast.makeText(this,"Aster: Größe geändert",Toast.LENGTH_SHORT).show();}else{pose=(pose+1)%poses.length;pet.setImageResource(poses[pose]);}}return true;
        }return true;}); wm.addView(pet,params);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){if(pet==null)showPet();return START_STICKY;}
    @Override public void onDestroy(){if(pet!=null){try{wm.removeView(pet);}catch(Exception ignored){}pet=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
