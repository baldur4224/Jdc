package de.baldurskreativa.aster;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24),dp(28),dp(24),dp(24)); root.setBackgroundColor(Color.rgb(247,248,252));
        TextView title = new TextView(this); title.setText("Aster Otter"); title.setTextSize(30); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setTextColor(Color.rgb(30,42,64)); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Dein kleiner Otter – schwebend über deinen Apps"); sub.setTextSize(16); sub.setTextColor(Color.rgb(80,91,110)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(8);root.addView(sub,sp);
        TextView info = new TextView(this); info.setText("Aster hat einen transparenten Hintergrund. Ziehe ihn über den Bildschirm. Tippen wechselt seine Pose, langes Drücken ändert die Größe."); info.setTextSize(15); info.setTextColor(Color.rgb(50,61,80)); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(24);root.addView(info,ip);
        Button start = new Button(this); start.setText("Aster anzeigen"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(54));bp.topMargin=dp(24);root.addView(start,bp);
        start.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); } else { startService(new Intent(this,OtterOverlayService.class).setAction("START")); finish(); } });
        Button stop = new Button(this); stop.setText("Aster ausblenden"); LinearLayout.LayoutParams bp2=new LinearLayout.LayoutParams(-1,dp(54));bp2.topMargin=dp(8);root.addView(stop,bp2); stop.setOnClickListener(v -> { stopService(new Intent(this,OtterOverlayService.class)); });
        TextView note=new TextView(this);note.setText("Hinweis: Android fragt nach der Berechtigung „Über anderen Apps einblenden“. Erlaube sie, damit Aster auch außerhalb dieser App sichtbar sein darf.");note.setTextSize(13);note.setTextColor(Color.GRAY);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(24);root.addView(note,np);
        setContentView(root);
    }
    @Override protected void onResume(){super.onResume();}
}
