ASTER OTTER OVERLAY – APK ONLINE MIT GITHUB ACTIONS BAUEN

1. Melde dich bei https://github.com an.
2. Erstelle ein neues Repository, z. B. aster-otter-overlay. Für den einfachsten Weg kann es Private bleiben.
3. Entpacke dieses ZIP auf deinem Gerät.
4. Öffne das neue Repository auf GitHub und wähle „Add file“ > „Upload files“.
5. Lade ALLE INHALTE des Ordners aster_otter_android_overlay hoch (einschließlich des versteckten Ordners .github). Nicht nur die ZIP-Datei hochladen. Warte, bis der Upload abgeschlossen ist, und committe die Dateien auf den Branch main.
6. Öffne im Repository den Tab „Actions“. Falls gefragt, aktiviere GitHub Actions für das Repository.
7. Der Workflow „Build Aster APK“ startet beim Push automatisch. Alternativ: Actions > Build Aster APK > Run workflow.
8. Öffne den abgeschlossenen Lauf (grüner Haken), scrolle zu „Artifacts“ und lade „Aster-Otter-debug-APK“ herunter.
9. Entpacke das heruntergeladene Artifact-ZIP. Darin liegt app-debug.apk.
10. Übertrage die APK auf dein Android-Handy und installiere sie. Eventuell musst du für die verwendete Datei-App die Installation unbekannter Apps erlauben. Installiere APKs nur aus deinem eigenen Build und bewahre die Datei sicher auf.

HINWEISE
- Dies erstellt eine Debug-APK, keine signierte Play-Store-Version.
- Der Build kann beim ersten Versuch scheitern, wenn Quellcode oder Gradle-Konfiguration angepasst werden müssen. Dann öffne den fehlgeschlagenen Actions-Lauf und teile die Fehlermeldung.
- GitHub Actions baut den Code in der Cloud. Die APK ist damit nicht unabhängig geprüft oder garantiert fehlerfrei.
- Die APK ist für Android Overlay-Berechtigung vorgesehen. Android zeigt eine Systemabfrage für „Über anderen Apps einblenden“; diese muss der Nutzer selbst erlauben.
