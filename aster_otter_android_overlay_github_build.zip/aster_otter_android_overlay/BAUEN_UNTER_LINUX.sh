#!/usr/bin/env bash
set -e
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle wurde nicht gefunden. Öffne den Ordner in Android Studio und baue über Build > Build APK(s)."
  exit 1
fi
gradle assembleDebug
