# Aster Otter Overlay – Android Studio Projekt

Dies ist ein natives Android-Projekt für Aster als schwebendes Desktop-Pet auf dem Smartphone. Es nutzt die neuen Otter-PNGs aus der Desktop-Version; die Bilder werden unverändert mit Transparenz eingebunden.

## Funktionen
- Transparentes schwebendes Fenster über anderen Apps (Android Overlay-Berechtigung erforderlich)
- Otter durch Ziehen verschiebbar
- Tippen wechselt durch die Otter-Posen
- Langes Drücken wechselt zwischen drei Größen
- Offline: Bilder und Logik sind im Projekt enthalten

## APK bauen
1. ZIP entpacken.
2. Ordner `aster_otter_android_overlay` in Android Studio öffnen.
3. Gradle-Synchronisierung durchführen (Android Studio benötigt dafür ggf. Internet und Android SDK).
4. Menü **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Die APK aus `app/build/outputs/apk/debug/app-debug.apk` auf das Android-Gerät kopieren und installieren.

## Erste Nutzung
1. App starten und „Aster anzeigen“ drücken.
2. Android öffnet die Einstellung „Über anderen Apps einblenden“; Berechtigung erlauben.
3. Zurück zur App und erneut „Aster anzeigen“ drücken.
4. Aster bleibt über anderen Apps sichtbar. Ziehen bewegt ihn, Tippen ändert Pose, langes Drücken ändert Größe.

## Einschränkungen
- Das Paket ist ein Android-Studio-Projekt, keine bereits gebaute APK. In dieser Umgebung war kein Android-Buildsystem verfügbar, um eine echte APK zu kompilieren und zu testen.
- Manche Apps (z. B. geschützte Banking- oder Vollbild-Apps) können Overlays aus Sicherheitsgründen ausblenden.
- Android kann den Dienst bei Energiesparregeln beenden; bei Bedarf Akku-Optimierung für Aster lockern.
